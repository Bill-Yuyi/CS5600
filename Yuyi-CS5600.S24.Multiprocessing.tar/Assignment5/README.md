# Multiprocessing in C
## How to run
    make all: compile and run.
## Expected output
   Random words are stored in a file called words.
   For encoded words, they are stored in the outputs folder with 100 files under it.
## How to clean
    make clean