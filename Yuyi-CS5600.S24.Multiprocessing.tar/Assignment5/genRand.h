#include <stdio.h>

unsigned long lcg(unsigned long *seed);
int genRand(int min, int max);
void writeRandomWords(FILE *file);
