int my_strcmp(const char *s1, const char *s2);
void capitalize(const char *s, char *res);
int my_strlen(const char *s);
void string_concatenate(char *dest, char *s);
void upper(const char *s, char *res);
void lower(const char *s, char *res);
int command_checker(char *command);
void string_operation(const char *command, const char *original_str, char *dest, char *src, int i);