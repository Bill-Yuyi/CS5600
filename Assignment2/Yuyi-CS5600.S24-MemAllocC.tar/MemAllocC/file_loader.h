int countNumbersInLine(const char *line);
void fillArrayWithInts(const char *line, int *array, int maxCount);
void load2block(int count, const char *line, int *tempArray, int i, dynBlock *blocks[]);
