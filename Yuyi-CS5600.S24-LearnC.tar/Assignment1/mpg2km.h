double mpg2kml(double mpg);
double mpg2lphm(double mpg);
double lph2mpg(double lph);